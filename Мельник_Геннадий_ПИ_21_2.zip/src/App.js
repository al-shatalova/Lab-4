import Book from "./components/Books";
import {Search} from "@mui/icons-material";
import * as PropTypes from "prop-types";
import {AppBar, Box, Button, IconButton, InputBase, Toolbar, Typography} from "@mui/material";
import MenuIcon from '@mui/icons-material/Menu';
import SearchIcon from '@mui/icons-material/Search';
import { styled, alpha} from '@mui/material/styles';
import TopBook from "./components/Tops";

function SearchIconWrapper(props) {
	return null;
}

SearchIconWrapper.propTypes = {children: PropTypes.node};

function App() {
	const pages = ['Акции', 'Обмены', 'Циклы', 'Обзоры'];
	const BooksList =[{
		image: 'https://www.bookvoed.ru/files/1377/12/79/43/05.jpg',
		name: 'Путешествие в Элевсин',
		price: '949 ₽',
		author: 'Пелевин Виктор'
	},{
		image: 'https://www.bookvoed.ru/files/1836/55/89/30/6.jpeg',
		name: 'Гордость и предубеждение',
		price: '279 ₽',
		author: 'Остен Джейн'
	},{
		image: 'https://www.bookvoed.ru/files/1836/55/80/58/6.jpeg',
		name: 'Мартин Иден',
		price: '289 ₽',
		author: 'Лондон, Джек'
	},{
		image: 'https://www.bookvoed.ru/files/1836/11/56/30/97.jpeg',
		name: 'Евгений Онегин. Борис Годунов. Маленькие трагедии',
		price: '229 ₽',
		author: 'Алиса Жданова'
	},]
	const TopBooksList =[{
        image: 'https://www.bookvoed.ru/files/1836/11/50/76/08.jpeg',
        name: 'Голодные игры',
        price: '679 ₽',
        author: 'Коллинз Сьюзен'
    },{
		image: 'https://www.bookvoed.ru/files/1836/12/46/52/03.jpeg',
		name: '1984: роман',
		price: '579 ₽',
		author: 'Джордж Оруэлл'
	},{
		image: 'https://www.bookvoed.ru/files/1836/12/57/50/36.jpeg',
		name: '451 градус по Фаренгейту',
		price: '481 ₽',
		author: 'Брэдбери Рэй'
	},{
		image: 'https://www.bookvoed.ru/files/1836/12/37/98/51.jpeg',
		name: 'Мы',
		price: '500 ₽',
		author: 'Замятин Евгений Иванович'
	},{
		image: 'https://www.bookvoed.ru/files/1836/12/67/21/10.jpeg',
		name: 'О дивный новый мир',
		price: '349 ₽',
		author: 'Хаксли Олдос Леонард'
	},{
        image: 'https://www.bookvoed.ru/files/1836/61/74/38/6.jpg',
        name: 'Атлант расправил плечи. В 3 книгах',
        price: '1266 ₽',
        author: 'Айн Рэнд'
    },]
	const Search = styled('div')(({ theme }) => ({
  position: 'relative',
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 0.15),
  '&:hover': {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  marginLeft: 0,
  width: '100%',
  [theme.breakpoints.up('sm')]: {
    marginLeft: theme.spacing(1),
    width: 'auto',
  },
}));

const SearchIconWrapper = styled('div')(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: '100%',
  position: 'absolute',
  pointerEvents: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: 'inherit',
  '& .MuiInputBase-input': {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      width: '12ch',
      '&:focus': {
        width: '20ch',
      },
    },
  },
}));
  return (
		<>
			<AppBar position="static">
        <Toolbar>
          <IconButton
            size="large"
            edge="start"
            color="inherit"
            aria-label="open drawer"
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          <Typography
            variant="h6"
            noWrap
            component="div"
            sx={{ flexGrow: 1, display: { xs: 'none', sm: 'block' } }}
          >
            Буквоед
          </Typography>
	        <Box sx={{ flexGrow: 1, display: { xs: 'none', md: 'flex' } }}>
            {pages.map((page) => (
              <Button
                key={page}
                sx={{ my: 2,mr: 4, color: 'white', display: 'block' }}
              >
                {page}
              </Button>
            ))}
          </Box>
          <Search>
            <SearchIconWrapper>
              <SearchIcon />
            </SearchIconWrapper>
            <StyledInputBase
              placeholder="Поиск"
              inputProps={{ 'aria-label': 'Поиск' }}
            />
          </Search>
        </Toolbar>
      </AppBar>
			<center><h1>Топ 2022</h1></center>
    <div style={{display:"flex", marginLeft: 250}}>
	    {TopBooksList.map((item)=>
	    <TopBook {...item}
		    />
	    )}
	    </div>
			<center><h1>Актуальный топ</h1></center>
    <div style={{display:"flex", marginLeft: 250}}>
	    {BooksList.map((item)=>
	    <Book
		    {...item}
		    />
	    )}
    </div>
			</>
  );
}

export default App;
