import './App.css';



const books = [
  {
    id: 1,
    name: 'Психология влияния. Как научиться убеждать и добиваться успеха',
    author: 'Роберт Чалдини',
    imageUrl: "https://bombora.ru/upload/resize_cache/iblock/b8b/300_408_1/cover3d.jpg",
    year: '2020',
  },
  {
    id: 2,
    name: 'Кафе на краю земли. Как перестать плыть по течению и вспомнить, зачем ты живешь',
    author: 'Джон Стрелеки',
    imageUrl: "https://bombora.ru/upload/adwex.minified/webp/a32/80/a327f377c71092fcbad01ddf69a7895d.webp",
    year: '2021'
  },
  {
    id: 3,
    name: 'НИ СЫ. Будь уверен в своих силах и не позволяй сомнениям мешать тебе двигаться вперед',
    author: 'Джен Синсеро',
    imageUrl: "https://bombora.ru/upload/adwex.minified/webp/709/80/7098b8cf215869c91bbd2cc97248d014.webp",
    year: '2021'
  }
];

const books_2 = [
    {
    id: 4,
    name: 'Иди туда, где страшно. Именно там ты обретешь силу',
    author: 'Джим Лоулесс',
    imageUrl: "https://bombora.ru/upload/adwex.minified/webp/99f/80/99f4158f74eb2e6a90dfdae72c87d288.webp",
    year: '2020'
  },
  {
    id: 5,
    name: 'Ребенок в тебе должен обрести дом. Вернуться в детство, чтобы исправить взрослые ошибки',
    author: 'Стефани Шталь',
    imageUrl: "https://bombora.ru/upload/adwex.minified/webp/f1b/80/f1b201c713b3d28caa1c9c5515463718.webp",
    year: '2021'
  },
  {
    id: 6,
    name: 'Это началось не с тебя. Как мы наследуем сценарии семьи и как остановитьвлияние',
    author: 'Марк Уолинн',
    imageUrl: "https://bombora.ru/upload/adwex.minified/webp/308/80/3086d812b6dea0d12e543664eb821e25.webp",
    year: '2021'
  }
];
function Navigation() {
  return (
      <nav className="navbar navbar-expand-lg navbar-light">
        <a className="navbar-brand" href="#">Книги</a>
        <button className="navbar-toggler" type="button" data-toggle="collapse"
                data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item active">
              <a className="nav-link" href="#">Страница 1<span
                  className="sr-only"></span></a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">Страница 2</a>
            </li>
            <li className="nav-item dropdown">
              <a className="nav-link dropdown-toggle" href="#"
                 id="navbarDropdown" role="button" data-toggle="dropdown"
                 aria-haspopup="true" aria-expanded="false">
                Страница 3
              </a>
              <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                <a className="dropdown-item" href="#">Action</a>
                <a className="dropdown-item" href="#">Another action</a>
                <div className="dropdown-divider"></div>
                <a className="dropdown-item" href="#">Something else here</a>
              </div>
            </li>
            <li className="nav-item">
              <a className="nav-link disabled" href="#">Страница 4</a>
            </li>
          </ul>
          <form className="form-inline my-2 my-lg-0">
            <input className="form-control mr-sm-2" type="search"
                   placeholder="Поиск" aria-label="Search"/>
          </form>
        </div>
      </nav>
  )
}

function BookShow(props) {
  return (
    <div className='flex-container'>
      {props.data.map((book) => (
        <div className="column-container">
          <Book {...book}/>
        </div>
      ))}
    </div>
  );
}

function BookShow2(props) {
  return (
    <div className='flex-container'>
      {props.data.map((book) => (
        <div className="column-container">
          <Book2 {...book}/>
        </div>
      ))}
    </div>
  );
}
function Book(props) {
  return (
      <>
        <img className="BookImage" src={props.imageUrl}/>
        <p1 className="BookTitle"><b>{props.name}</b></p1>
        <p2 className="BookAuthor"><font size="3">{props.author}</font></p2>
        <p1 className="BookYear"><font size="2">{props.year}</font></p1>

      </>
  )
}
function Book2(props) {
  return (
      <>
        <img className="BookImage2" src={props.imageUrl}/>
        <p1 className="BookTitle"><b>{props.name}</b></p1>
        <p2 className="BookAuthor"><font size="3">{props.author}</font></p2>
        <p1 className="BookYear"><font size="2">{props.year}</font></p1>

      </>
  )
}

function App() {
  return (
    <div className="App">
      <Navigation/>
      <BookShow data={books}/>
      <BookShow2 data={books_2}/>
    </div>
  )
}
export default App;