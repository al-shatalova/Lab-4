export default function Footer() {
  return (
    <footer>
      &copy; Книжный магазин, 2023 <br />
      Все права защищены
    </footer>
  );
}
