import books from '../books.js';
import Book from './Book.jsx';

function Card({children}) {
  return (
    <div className="container">
      {children}
    </div>
  )
}

export default function Bookrow({ title }) {
  const filteredBooks = books.filter((book) => book.category === title);

  return (
    <Card>
      <section className="bookrow">
        <h2>{title}</h2>
        <div className="bookrow__books">
          {filteredBooks.map((book) => (
            <Book
              key={book.id}
              cover={book.cover}
              title={book.title}
              author={book.author}
              price={book.price}
              category={title}
            />
          ))}
        </div>
      </section>
    </Card>
  );
}
