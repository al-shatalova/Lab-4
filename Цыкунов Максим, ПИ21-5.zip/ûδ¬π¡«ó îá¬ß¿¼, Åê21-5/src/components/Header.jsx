export default function Header() {
  return (
    <header>
      <div className="container">
        <div className="logo">Книжный магазин</div>
        <nav>
          <a href="#">Книги</a>
          <a href="#">Обзоры</a>
          <a href="#">Статьи</a>
          <a href="#">Интервью</a>
          <a href="#">Адреса</a>
          <a href="#">Контакты</a>
        </nav>
      </div>
    </header>
  );
}
