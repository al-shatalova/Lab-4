export default function Book(book) {
  return (
    <div className="book">
      <img src={book.cover} alt="" className={book.category === 'Новинки' ? 'big' : ''}/>
      <div className="title">{book.title}</div>
      <div className="author">{book.author}</div>
      <div className="price">{book.price}₽</div>
    </div>
  );
}
