import { useState } from 'react'
import './App.css'
import Header from "./components/Header.jsx";
import ImgGen from "./components/ImgGen.jsx";
import Wrapper from "./components/Wrapper.jsx";

function App() {
  const [count, setCount] = useState(0)
  const data = [
    {key: 1, imageUrl: 'https://img4.labirint.ru/rc/b2f14c027cae1f9887fdcf2a31e52d32/363x561q80/books99/981058/cover.jpg?1695648428', description: 'Путешествие в мир обычной семьи. Новый роман Энн Тайлер', cost: 750},
    {key: 2, imageUrl: 'https://img3.labirint.ru/rc/1380e028d3a2109600d7fa92fa1d9368/363x561q80/books98/970727/cover.jpg?1693409161', description: 'Заключительный роман из цикла «Эбби Маллен»', cost: 1200},
    {key: 3, imageUrl: 'https://img3.labirint.ru/rc/4072f8e54ebcafc100a019dbabb420b5/363x561q80/books98/971825/cover.jpg?1693632304', description: 'Тыква с новой стороны. 40 иллюстрированных рецептов', cost: 1000},
    {key: 4, imageUrl: 'https://img4.labirint.ru/rc/797215d61fb1284ef32bf6e39549138a/363x561q80/books97/964600/cover.png?1697523931', description: 'Иллюстрированное исследование о роли игры в культуре и жизни', cost: 325},
    {key: 5, imageUrl: 'https://img3.labirint.ru/rc/5dbc30ca5630d58e4bda66b705f238fe/363x561q80/books99/982361/cover.jpg?1696656333', description: 'Триллер об эксперименте, который пошел наперекосяк', cost: 746},
    {key: 6, imageUrl: 'https://img3.labirint.ru/rc/1aac34adc1e6a1f5103ff469637dbf45/363x561q80/books98/979701/cover.jpg?1698045908', description: 'Истребитель демонов. Том 11. Сражаются все', cost: '12000'},
    {key: 7, imageUrl: 'https://img4.labirint.ru/rc/13b6b175c62784cff5debfa428c73c47/363x561q80/books98/979716/cover.jpg?1695230712', description: 'Каратель MAX. Полное собрание. Том 2', cost: 234},
    {key: 8, imageUrl: 'https://img3.labirint.ru/rc/417d945a8e5b3456af8b724e320747cf/363x561q80/books98/972323/cover.jpg?1697869502', description: 'После Банкета', cost: 1999},
    {key: 9, imageUrl: 'https://img4.labirint.ru/rc/666b133c8a32901efc7d0bbd279749fb/363x561q80/books99/985320/cover.jpg?1697815532', description: 'Мышление и речь', cost: 320},
    {key: 10, imageUrl: 'https://img.labirint.ru/images/att/news/1-57984-1696419682-6894-cover.png', description: 'Рассказываем о книге Алексея Корнелюка «Второй шанс умереть»', cost: 399},
    {key: 11, imageUrl: 'https://img3.labirint.ru/rc/9c467d6727ea654493d73507ee903a53/363x561q80/books96/953885/cover.jpg?1686144439', description: 'The Wind in the Willows', cost: 999},
    {key: 12, imageUrl: 'https://img4.labirint.ru/rc/2bb1cd43200223f2db6032a9ef5841a9/363x561q80/books85/848214/cover.png?1677770713', description: 'Одноразовый сотрудник — очень полезный ресурс для корпорации', cost: 599},
  ]

  return (
    <>
      <Header/>

      <section>

        <h2>ЧТО ПОЧИТАТЬ: ВЫБОР РЕДАКЦИИ</h2>
        <Wrapper>
          {data.map((rowData) => (
              <ImgGen data={rowData} key={rowData.id} size={200}/>
          ))}
        </Wrapper>

        <h2>ЧИТАТЕЛИ ВЫБИРАЮТ СЕГОДНЯ</h2>
        <Wrapper>
          {data.map((rowData) => (
              <ImgGen data={rowData} key={rowData.id} size={100}/>
          ))}
        </Wrapper>
      </section>

    </>
  )
}

export default App
