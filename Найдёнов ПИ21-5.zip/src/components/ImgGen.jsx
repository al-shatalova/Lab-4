import React from 'react';



const ImgGen = (props) => {
    return (
        <div className={"product"}>
            <img  src={props.data.imageUrl} alt="" height = {props.size}/>
            <p><strong>{props.data.cost}руб</strong></p>
            <p>{props.data.description}</p>
            <button>добавить</button>
        </div>
    );
};

export default ImgGen;