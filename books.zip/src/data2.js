export const books = [
  {
    id: 5,
    name: "Оно",
    profession: "1500",
    accomplishment:
      "Роман американского писателя Стивена Кинга, написанный в жанре ужасов, впервые опубликованный в 1986 году издательством «Viking Press».",
    imageId: "оно"
  }
];
