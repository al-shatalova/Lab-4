import List from "./text.js";
import Avatar from "./Avatar.js";
function Card({ children, children2 }) {
  return <div className="card">{[children, children2]}</div>;
}

function Nav() {
  return (
    <div class="container">
      <header class="d-flex justify-content-center py-3">
        <ul class="nav nav-pills">
          <li class="nav-item">
            <a href="1" class="nav-link px-2 link-dark" aria-current="page">
              Домашняя страница
            </a>
          </li>
          <li class="nav-item">
            <a href="1" class="nav-link px-2 link-dark">
              О нас
            </a>
          </li>
          <li class="nav-item">
            <a href="1" class="nav-link px-2 link-dark">
              Корзина
            </a>
          </li>
          <li class="nav-item">
            <a href="1" class="nav-link px-2 link-dark">
              Бестселлеры
            </a>
          </li>
          <li class="nav-item">
            <a href="1" class="nav-link px-2 link-dark">
              Контакты
            </a>
          </li>
        </ul>
      </header>
      <div>
        <h1>КНИГИ СТИВЕНА КИНГА</h1>
      </div>
    </div>
  );
}

export default function Res() {
  return (
    <Card>
      <Nav />
      <List />
      <Avatar
        size1={500}
        size2={500}
        person={{
          name: "оно",
          imageId: "оно"
        }}
      />
    </Card>
  );
}
