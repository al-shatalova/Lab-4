import { people } from "./data.js";
import { getImageUrl } from "./utils.js";

export default function List({ person_id }) {
  const listItems = people.map((person) => (
    <div key={person_id}>
      <img src={getImageUrl(person)} alt={person.name} />
      <p>
        <b>{person.name}</b>
      </p>
      <p>{person.accomplishment}</p>
      <b>{"Цена: " + person.profession + "р"}</b>
      <p>
        <div class="btn btn-outline-primary">В корзину</div>
      </p>
    </div>
  ));
  return <div class="flex-container">{listItems}</div>;
}
