export function getImageUrl(person, size = ".jpg") {
  return person.imageId + size;
}
