<img
  className="avatar"
  src={getImageUrl(person)}
  alt={person.name}
  width={size}
  height={size}
/>;

const listItems = people.map((person) => (
  <div key={person.id}>
    <img src={getImageUrl(person)} alt={person.name} />
    <p>
      <b>{person.name}</b>
    </p>
    <p>{person.accomplishment}</p>
    <b>{"Цена: " + person.profession + "р"}</b>
    <p>
      <h3></h3>
      <div class="btn btn-outline-primary">В корзину</div>
    </p>
  </div>
));
