import { getImageUrl } from "./utils.js";

export default function Avatar({ person, size1, size2 }) {
  return (
    <div>
      <h1>
        <b>Бестселлер</b>
      </h1>
      <img
        className="avatar"
        src={getImageUrl(person)}
        alt={person.name}
        style={{ height: size1, width: size2 }}
      />
    </div>
  );
}
