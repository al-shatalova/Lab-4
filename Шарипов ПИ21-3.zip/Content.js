import React from 'react';
import image_1 from './Images/oil_1.png'
import image_2 from './Images/oil_2.jpg'
import {Link} from "react-router-dom";

export default function Content() {


    return (<>
            <div>
                <div className="album py-5 bg-body-tertiary">
                    <div className="container">

                        <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                            <div className="col">
                                <div className="card shadow-sm">
                                    <img src={image_1} style={{height: 150, width: 150, marginLeft: 100}}/>
                                    <div className="card-body">
                                        <p className="card-text">This is a wider card with supporting text below as
                                            a
                                            natural lead-in to additional content. This content is a little bit
                                            longer.</p>
                                        <div className="d-flex justify-content-between align-items-center">
                                            <div className="btn-group">
                                                <Link to={"/Kartochka"}>
                                                    <button type="button"
                                                            className="btn btn-sm btn-outline-secondary">Смотреть
                                                    </button>
                                                </Link>
                                                <button type="button"
                                                        className="btn btn-sm btn-outline-secondary"
                                                >Купить
                                                </button>
                                            </div>
                                            <small className="text-body-secondary">1000 руб</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col">
                                <div className="card shadow-sm">
                                    <img src={image_2} style={{height: 150, width: 150, marginLeft: 100}}/>
                                    <div className="card-body">
                                        <p className="card-text">This is a wider card with supporting text below as
                                            a
                                            natural lead-in to additional content. This content is a little bit
                                            longer.</p>
                                        <div className="d-flex justify-content-between align-items-center">
                                            <div className="btn-group">
                                                <button type="button"
                                                        className="btn btn-sm btn-outline-secondary">Смотреть
                                                </button>
                                                <button type="button"
                                                        className="btn btn-sm btn-outline-secondary">Купить
                                                </button>
                                            </div>
                                            <small className="text-body-secondary">1000 руб</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col">
                                <div className="card shadow-sm">
                                    <img src={image_1} style={{height: 150, width: 150, marginLeft: 100}}/>
                                    <div className="card-body">
                                        <p className="card-text">This is a wider card with supporting text below as
                                            a
                                            natural lead-in to additional content. This content is a little bit
                                            longer.</p>
                                        <div className="d-flex justify-content-between align-items-center">
                                            <div className="btn-group">
                                                <button type="button"
                                                        className="btn btn-sm btn-outline-secondary">Смотреть
                                                </button>
                                                <button type="button"
                                                        className="btn btn-sm btn-outline-secondary">Купить
                                                </button>
                                            </div>
                                            <small className="text-body-secondary">1000 руб</small>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="col">
                                <div className="card shadow-sm">
                                    <img src={image_1} style={{height: 150, width: 150, marginLeft: 100}}/>
                                    <div className="card-body">
                                        <p className="card-text">This is a wider card with supporting text below as
                                            a
                                            natural lead-in to additional content. This content is a little bit
                                            longer.</p>
                                        <div className="d-flex justify-content-between align-items-center">
                                            <div className="btn-group">
                                                <button type="button"
                                                        className="btn btn-sm btn-outline-secondary">Смотреть
                                                </button>
                                                <button type="button"
                                                        className="btn btn-sm btn-outline-secondary">Купить
                                                </button>
                                            </div>
                                            <small className="text-body-secondary">1000 руб</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col">
                                <div className="card shadow-sm">
                                    <img src={image_1} style={{height: 150, width: 150, marginLeft: 100}}/>
                                    <div className="card-body">
                                        <p className="card-text">This is a wider card with supporting text below as
                                            a
                                            natural lead-in to additional content. This content is a little bit
                                            longer.</p>
                                        <div className="d-flex justify-content-between align-items-center">
                                            <div className="btn-group">
                                                <button type="button"
                                                        className="btn btn-sm btn-outline-secondary">Смотреть
                                                </button>
                                                <button type="button"
                                                        className="btn btn-sm btn-outline-secondary">Купить
                                                </button>
                                            </div>
                                            <small className="text-body-secondary">1000 руб</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col">
                                <div className="card shadow-sm">
                                    <img src={image_1} style={{height: 150, width: 150, marginLeft: 100}}/>
                                    <div className="card-body">
                                        <p className="card-text">This is a wider card with supporting text below as
                                            a
                                            natural lead-in to additional content. This content is a little bit
                                            longer.</p>
                                        <div className="d-flex justify-content-between align-items-center">
                                            <div className="btn-group">
                                                <button type="button"
                                                        className="btn btn-sm btn-outline-secondary">Смотреть
                                                </button>
                                                <button type="button"
                                                        className="btn btn-sm btn-outline-secondary">Купить
                                                </button>
                                            </div>
                                            <small className="text-body-secondary">1000 руб</small>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="col">
                                <div className="card shadow-sm">
                                    <img src={image_2} style={{height: 150, width: 150, marginLeft: 100}}/>
                                    <div className="card-body">
                                        <p className="card-text">This is a wider card with supporting text below as
                                            a
                                            natural lead-in to additional content. This content is a little bit
                                            longer.</p>
                                        <div className="d-flex justify-content-between align-items-center">
                                            <div className="btn-group">
                                                <button type="button"
                                                        className="btn btn-sm btn-outline-secondary">Смотреть
                                                </button>
                                                <button type="button"
                                                        className="btn btn-sm btn-outline-secondary">Купить
                                                </button>
                                            </div>
                                            <small className="text-body-secondary">1000 руб</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col">
                                <div className="card shadow-sm">
                                    <img src={image_2} style={{height: 150, width: 150, marginLeft: 100}}/>
                                    <div className="card-body">
                                        <p className="card-text">This is a wider card with supporting text below as
                                            a
                                            natural lead-in to additional content. This content is a little bit
                                            longer.</p>
                                        <div className="d-flex justify-content-between align-items-center">
                                            <div className="btn-group">
                                                <button type="button"
                                                        className="btn btn-sm btn-outline-secondary">Смотреть
                                                </button>
                                                <button type="button"
                                                        className="btn btn-sm btn-outline-secondary">Купить
                                                </button>
                                            </div>
                                            <small className="text-body-secondary">1000 руб</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col">
                                <div className="card shadow-sm">
                                    <img src={image_1} style={{height: 150, width: 150, marginLeft: 100}}/>
                                    <div className="card-body">
                                        <p className="card-text">This is a wider card with supporting text below as
                                            a
                                            natural lead-in to additional content. This content is a little bit
                                            longer.</p>
                                        <div className="d-flex justify-content-between align-items-center">
                                            <div className="btn-group">
                                                <Link to={"/CardOfItem"}>
                                                    <button type="button"
                                                            className="btn btn-sm btn-outline-secondary">Смотреть
                                                    </button>
                                                </Link>
                                                <button type="button"
                                                        className="btn btn-sm btn-outline-secondary">Купить
                                                </button>
                                            </div>
                                            <small className="text-body-secondary">1000 руб</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );

}


