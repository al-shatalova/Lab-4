import React, {useState} from 'react';
import {Button} from "react-bootstrap";
import image_1 from './Images/oil_1.png'


function Card({children}) {

    return (
        <div className="row">{children}</div>
    );
}


function BookList() {
    const Spisokkorzina = [
        {
            price: 1000,
            count: 0,
            image: image_1
        }
    ];
    Spisokkorzina.push({price: 1500, count: 0, image: image_1})


    const ListItem = ({image, count, price}) => {
        let [coun, setCount] = useState(0);
        return (
            <div className="grid-item card border-0">
                <img src={image} style={{height: 300}}/>
                <p>Количество {count}</p>
                <p>Цена {count * price}</p>
                <Button variant="primary">Купить</Button>
                <button onClick={() => setCount(coun += 1)}> Добавить</button>
                <button onClick={() => setCount(coun = 0)}> Удалить</button>
                <p>Добавлено {coun} единиц товара</p>
            </div>
        );
    }




    return (
        <div className="container">
            <Card>
                {Spisokkorzina.map((sk) => (
                    <div className="col-md-3">
                        <ListItem {...sk} />
                        <br></br>
                    </div>
                ))}
            </Card>
        </div>
    );
}

export default BookList;






