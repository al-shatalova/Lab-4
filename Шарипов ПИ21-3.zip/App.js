import React, {Component} from 'react';
import Header from "./Header";
import Content from "./Content";
import Home from "./Home";
import {Route, Routes} from "react-router-dom";
import Korzina from "./Korzina";
import Kartochka from "./Kartochka";
class App extends Component{
    render() {
        return (
            <Routes>
                <Route path='/' element={<Home />} />
                <Route path='/Korzina' element={<Korzina />} />
                <Route path='/Kartochka' element={<Kartochka />} />
            </Routes>

        );
    }
}

export default App;