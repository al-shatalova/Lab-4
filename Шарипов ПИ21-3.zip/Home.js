import React from 'react';
import image from './Images/v8_logo.jpg'
import {Link} from "react-router-dom";
import Header from "./Header";
import Content from "./Content";
export default function Home() {


    return (<>
            <Header />
            <Content />
        </>

    );

}

