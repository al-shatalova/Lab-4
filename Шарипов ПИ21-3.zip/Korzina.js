import React from 'react';
import image from './Images/v8_logo.jpg'
import Header from "./Header";
import ListItem from "./Items";
import Items from "./Items";


export default function Korzina() {


    return (<>
            <Header/>
            <ListItem/>
        </>
    );

}